
package com.mycompany.testageradordeextrato;


public class Conta {
       private double saldo;

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
       
       
}
