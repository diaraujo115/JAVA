
package com.mycompany.testageradordeextrato;

public class ContaPoupanca extends Conta{
    private int diaDoAniversario;

    public int getDiaDoAniversario() {
        return diaDoAniversario;
    }

    public void setDiaDoAniversario(int diaDoAniversario) {
        this.diaDoAniversario = diaDoAniversario;
    }
    
    
    
}
